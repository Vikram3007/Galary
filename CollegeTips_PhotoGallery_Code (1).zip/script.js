const filterButtons = document.querySelectorAll('.filter-btn');
const galleryItems = document.querySelectorAll('.gallery-item');
const modal = document.getElementById('modal');
const modalImg = document.getElementById('modal-img');
const modalDesc = document.getElementById('modal-image-desc');
const modalClose = modal.querySelector('.close-btn');

// Filter function
filterButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    // Update aria-pressed and active class
    filterButtons.forEach(b => {
      b.classList.remove('active');
      b.setAttribute('aria-pressed', 'false');
    });
    btn.classList.add('active');
    btn.setAttribute('aria-pressed', 'true');

    const filter = btn.getAttribute('data-filter');
    galleryItems.forEach(item => {
      if (filter === 'all' || item.getAttribute('data-category') === filter) {
        item.style.display = 'block';
      } else {
        item.style.display = 'none';
      }
    });
  });
});

// Open modal on click or keyboard enter/space
galleryItems.forEach(item => {
  item.addEventListener('click', () => {
    openModal(item);
  });
  item.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      openModal(item);
    }
  });
});

function openModal(item) {
  const img = item.querySelector('img');
  const caption = item.querySelector('.caption').textContent;
  modal.style.display = 'flex';
  modalImg.src = img.src;
  modalImg.alt = img.alt;
  modalDesc.textContent = caption;
  modal.focus();
}

// Close modal
function closeModal() {
  modal.style.display = 'none';
  modalImg.src = '';
  modalImg.alt = '';
}

modalClose.addEventListener('click', closeModal);
modalClose.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    closeModal();
  }
});

// Close modal on clicking outside the image
modal.addEventListener('click', e => {
  if (e.target === modal) closeModal();
});

// Close modal on ESC key
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && modal.style.display === 'flex') {
    closeModal();
  }
});
